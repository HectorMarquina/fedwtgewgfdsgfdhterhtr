package mx.edu.utez.adoptameapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdoptameAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
