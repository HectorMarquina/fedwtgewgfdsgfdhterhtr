package mx.edu.utez.adoptameapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdoptameAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdoptameAppApplication.class, args);
	}

}
